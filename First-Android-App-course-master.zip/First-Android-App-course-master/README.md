# First-Android-App-course
Codes written and project done during Build Your First Android App (Project-Centered Course) course on coursera is uploaded here.
Link : https://www.coursera.org/learn/android-app/home/welcome
